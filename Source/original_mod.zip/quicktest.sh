#!/usr/bin/bash

"/c/Program Files (x86)/Steam/steamapps/common/RimWorld/RimWorldWin64.exe" -quicktest